DATABASE SYNC TOOL
=================

1. Edit config.json with DB and API details.
2. Run sync.bat to start sync.
3. Logs saved in sync.log.
4. For silent run, double-click sync_silent.vbs.
